<?php defined('C5_EXECUTE') or die("Access Denied."); ?>

<?php
$info = array();
$view->inc('form_setup_html.php', array('info' => $info, 'c' => $c));
?>